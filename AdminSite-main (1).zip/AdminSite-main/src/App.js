import React from "react";
import AdminPage from "./components/AdminPage";

function App() {
    return ( < div >
        <
        AdminPage / >
        <
        /div>
    );
}

export default App;